/*eslint-env browser*/
/*eslint "no-console": "off"*/
/*global $*/
var myorientation;


$(function () {
    $(".loader").hide();


    //            function to check orientation every time it changes
    //        window.addEventListener("orientationchange", function () {
    //    
    //            setTimeout(function () {
    //                getOrientation();
    //    
    //                if (myorientation == "Landscape") {
    //                    defaultView();
    //                } else if (myorientation == "Portrait") {
    //                    defaultView();
    //                }
    //            }, 100);
    //    
    //        });
    $(".backButton").on("click", function () {
        defaultView();
        // window.removeEventListener("orientationchange", gameOnclick);
    });

    $(".backToGamesButton").on("click", function () {
        defaultView();
        // window.removeEventListener("orientationchange", gameOnclick);
    });

    $("header").on("click", function () {
        location.reload();
    });

    $("#filterByTeam").on("change", updateFilteredTeams);



    //Instead of this, you can make something like... (Go to line 65)
    gameOnclick("game1");
    gameOnclick("game2");
    gameOnclick("game3");
    gameOnclick("game4");
    gameOnclick("game5");
    gameOnclick("game6");
    gameOnclick("game7");
    gameOnclick("game8");
    gameOnclick("game9");
    gameOnclick("game10");
    gameOnclick("game11");
    gameOnclick("game12");
    gameOnclick("game13");
    gameOnclick("game14");
    gameOnclick("game15");
    gameOnclick("game16");
    gameOnclick("game17");




    /* Remove this multiline comments to see the code

    //We can store all the buttons that has the word 'game' in its class...
    var mybuttons = $('button[class^="game"]');

    //For one of them we initialize the listener...
    $.each(mybuttons, function (index, everyButton) {
        //     //Get the first class of every button
        var firstClass = $(everyButton).attr("class").split(" ")[0];

        //Start the listener
        gameOnclick(firstClass);
    })

    */



    /*
    //But if you want to play "hard code" is easy to create an unique listener. Like this

    function gameOnclick() {
        
        //We need to get the buttons for a unique class
        $(".gbut").click(function () {
            //Get the first class, in this case 'game1' etc... and store it.
            var att = $(this).attr("class").split(" ")[0];

            getOrientation();

            if (myorientation == "Landscape") {
                $(".games_info > div").hide();
                //Use this class to get the element with this id
                $("#" + att).show();
                $(".container").show();
                $(".backButton").hide();
                $(".filter").show();
            } else if (myorientation == "Portrait") {
                $(".games_info > div").hide();
                $("#" + att).show();
                $(".container").hide();
                $(".backButton").show();
                $(".filter").hide();

            } window.addEventListener("orientationchange", function () {
                setTimeout(function () {
                    getOrientation();

                    if (myorientation == "Portrait") {
                        $(".container").show();
                        $(".games_info > div").hide();
                        $(".backButton").show();
                        $(".filter").hide();
                    } else if (myorientation == "Landscape") {
                        $(".container").show();
                        $(".backButton").hide();
                        $(".filter").show();
                    }
                }, 100);

            });

        });
    }
    //Now you only need to initilize it once
    gameOnclick();


    //NOW YOU CAN REMOVE YOUR 17 FUNCTION CALLS ;)
    */



    $(".logInButton").on("click", function () {
        $("#logInPage").show();
        $("#mainPage").hide();
        $(".backToGamesButton").show();
        //        window.addEventListener("orientationchange", function () {
        //            setTimeout(function () {
        //                getOrientation();
        //
        //                if (myorientation == "Landscape") {
        //                    
        //                    $(this).css("transform", "rotate(90deg)");
        //                    
        //                }
        //            }, 100);
        //        });
    });
});

function getOrientation() {
    myorientation = window.innerWidth > window.innerHeight ? "Landscape" : "Portrait";
    return myorientation;
}



function gameOnclick(gameClass) {

    $("." + gameClass).click(function () {

        getOrientation();

        if (myorientation == "Landscape") {
            $(".games_info > div").hide();
            $("#" + gameClass).show();
            $(".container").show();
            $(".backButton").hide();
            $(".filter").show();
            //            $(".buttons button").css("opacity", "0.8");
            //            $("." + gameClass).css("opacity", "1");
        } else if (myorientation == "Portrait") {
            $(".games_info > div").hide();
            $("#" + gameClass).show();
            $(".container").hide();
            $(".backButton").show();
            $(".filter").hide();

        } window.addEventListener("orientationchange", function () {
            setTimeout(function () {
                getOrientation();

                if (myorientation == "Portrait") {
                    $(".container").show();
                    $(".games_info > div").hide();
                    $(".backButton").show();
                    $(".filter").hide();
                } else if (myorientation == "Landscape") {
                    $(".container").show();
                    $(".backButton").hide();
                    $(".filter").show();
                }
            }, 100);

        });

    });
}

function defaultView() {
    $("#mainPage").show();
    $(".header").show();
    $("#selectors").show();
    $(".container").show();
    $(".filter").show();
    $(".backButton").hide();
    $(".logInButton").show();
    $(".games_info > div").hide();
    $("#logInPage").hide();
    $(".backToGamesButton").hide();
    $(".buttons button").css("opacity", "0.8");
}


function updateFilteredTeams() {

    var teamFilter = $("#filterByTeam").val();

    $(".buttons button").each(function () {

        var theTeam = $(this).find(".teams").html();

        if (teamFilter == "" || theTeam.includes(teamFilter) == true) {
            $(this).slideDown("fast", function () {
                $(this).show();
                $(".games_info > div").hide();
                //                $("#landscapeMessage").show();
            });
        } else {
            $(this).hide();
            $(".games_info > div").hide();
            //            $("#landscapeMessage").show();
        }
    });

}
